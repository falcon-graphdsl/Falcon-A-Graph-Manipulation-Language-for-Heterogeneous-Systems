
#include<stdio.h>
#include<stdlib.h>
int main(int arc,char *argv[]){
int num_points=atoi(argv[1]);
int num_parts=atoi(argv[2]);
fprintf(stderr,"%d %d \n",num_points,num_parts);
FILE *FP=fopen(argv[3], "w+");
fprintf(FP,"%d\n0\n",num_points);
for(int i=1;i<num_points;i++)fprintf(FP,"%d\n",rand()%num_parts);
}

