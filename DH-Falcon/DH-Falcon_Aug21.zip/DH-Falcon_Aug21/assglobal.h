__device__ int falcgraphpoint,falcgraphedge;
