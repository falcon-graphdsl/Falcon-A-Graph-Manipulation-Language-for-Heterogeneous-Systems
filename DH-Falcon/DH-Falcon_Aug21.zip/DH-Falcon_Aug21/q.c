#include<stdio.h>
#include<stdlib.h>
main(){
FILE *fp=fopen("qq.txt","w+");
fprintf(fp,"%d\n0\n",10);
}
