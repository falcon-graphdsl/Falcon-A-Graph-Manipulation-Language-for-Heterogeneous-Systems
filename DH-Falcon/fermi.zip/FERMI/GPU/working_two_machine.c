#include <mpi.h>
#include "HGraph.h"
#include "multicoresssp2.h"
#include <stdio.h>
#include <unistd.h>
struct buffer {
int *vid;
int *dist;
}recvbuff,sendbuff;
int recvsize,sendsize;
int changed;
 void   relaxgraph ( int & p ,HGraph & graph ) 
 {

 if( ((struct struct_hgraph  *)(graph.extra))->updated[p]==true ){

int unni0=graph.index[p+1]-graph.index[p];;
int unni1=graph.index[p];
for(int unni2=0;unni2<unni0;unni2++){
int ut0=2*(unni1+unni2);
 int ut1=graph.edges[ut0].ipe;
int ut2=graph.edges[ut0+1].ipe;


  int   dist2 =((struct struct_hgraph  *)(graph.extra))->dist[ut1];

 HMIN(&(((struct struct_hgraph  *)(graph.extra))->dist[ut1]),((struct struct_hgraph  *)(graph.extra))->dist[p]+ut2,p,changed);//rhs not null


 if( ((struct struct_hgraph  *)(graph.extra))->dist[ut1]<dist2 )((struct struct_hgraph  *)(graph.extra))->updated1[ut1]=true; 

 }//foreach

 }

 }
int main(int argc, char **argv)
{
  int rank;
HGraph hgraph;
  char hostname[256];
printf("%s %s %s\n",argv[0],argv[1],argv[2]);
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
int world_size,number=1;
MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    MPI_Status status;

  gethostname(hostname,255);
hgraph.readPointsN(argv[2],2);
hgraph.makeNPartitionsMPI(argv[1],rank,2);
sendbuff.vid=(int *)malloc(sizeof(int)*hgraph.hostparts[0].remote_points);
sendbuff.dist=(int *)malloc(sizeof(int)*hgraph.hostparts[0].remote_points);
recvbuff.vid=(int  *)malloc(sizeof(int)*(1024*1024));
recvbuff.dist=(int  *)malloc(sizeof(int)*(1024*1024));
fprintf(stderr, "hgraph %d %d \n",hgraph.hostparts[0].npoints,hgraph.hostparts[0].remote_points);
int hosthgraph=1;
int number_amount;
hgraph.hostparts[0].extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph.hostparts[0],hosthgraph,hgraph.npoints+hgraph.remote_points);
 #pragma omp parallel  num_threads(12)
 for(int i=0;i<hgraph.npoints+hgraph.remote_points;i++){
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated[i]=false; 
 }//foreach
if(rank==0){
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[0]=0; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated[0]=true; 
}
int cnt=0;
int messageno=0;
 while(1)  { 
 changed=0;
++cnt; 
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph.hostparts[0].npoints;i++)relaxgraph(i,hgraph.hostparts[0]);
fprintf(stderr,"RG DONE %d\n",rank);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph.hostparts[0].npoints;i<hgraph.hostparts[0].npoints+hgraph.hostparts[0].remote_points;i++){
int loc;
if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&sendsize,1);
sendbuff.vid[loc]=hgraph.remotevertexid[i];
sendbuff.dist[loc]=((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[i]=false;
}
fprintf(stderr,"Sendbuff DONE %d\n",rank);
fprintf(stderr,"%d %d %d\n",sendsize,rank,messageno);
if(rank==0)MPI_Send((sendbuff.vid), sendsize, MPI_INT, (rank+1)%2,messageno, MPI_COMM_WORLD);
if(rank==1) MPI_Recv(recvbuff.vid,1024*1024, MPI_INT,(rank+1)%2, messageno, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
if(rank==1)MPI_Send((sendbuff.vid), sendsize, MPI_INT, (rank+1)%2,messageno, MPI_COMM_WORLD);
if(rank==0) MPI_Recv(recvbuff.vid,1024*1024, MPI_INT,(rank+1)%2, messageno, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
MPI_Barrier( MPI_COMM_WORLD ) ; 
fprintf(stderr,"X %d \n",rank);

if(rank==0)MPI_Send((sendbuff.dist), sendsize, MPI_INT, (rank+1)%2,messageno+1, MPI_COMM_WORLD);
if(rank==1) MPI_Recv(recvbuff.dist,1024*1024, MPI_INT, (rank+1)%2,messageno+1, MPI_COMM_WORLD,&status);
if(rank==1)MPI_Send((sendbuff.dist), sendsize, MPI_INT, (rank+1)%2,messageno+1, MPI_COMM_WORLD);
if(rank==0) MPI_Recv(recvbuff.dist,1024*1024, MPI_INT, (rank+1)%2,messageno+1, MPI_COMM_WORLD,&status);
MPI_Barrier( MPI_COMM_WORLD ) ;
fprintf(stderr,"XX %d\n",rank);
fprintf(stderr,"XXX %d\n",rank);
fprintf(stderr,"XXXX %d\n",rank);
messageno+=2;
   MPI_Get_count(&status, MPI_INT, &number_amount);
printf(" SIZE %d rank %d \n",number_amount,rank);
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<number_amount;i++){

int vertex= recvbuff.vid[i];
int dist= recvbuff.dist[i];
if(((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[vertex] >dist){
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[vertex]=dist;
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[vertex]=true;
} 
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph.hostparts[0].npoints;i++){
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated[i]=((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[i];
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[i]=false;
}
if(cnt==24)break;
sendsize=0;

}
  printf("Hello world!  I am process number: %d on host %s\n", rank, hostname);

  MPI_Finalize();
int maxdist=0,cnt1=0;
 for (int   i =0;i<hgraph.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]>maxdist &&((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]!=1234567890)maxdist=((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i];
printf("%d\n",maxdist);
 for (int   i =0;i<hgraph.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]==1234567890)cnt1++;
printf("%d\n",cnt1);
  return 0;
}

