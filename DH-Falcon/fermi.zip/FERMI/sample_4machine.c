#include "multicoresssp2.h"
 int   changed =0, hchanged ;
struct buffer{
int vid;
int dist;
}**part1buff,**part2buff,**part3buff,**part4buff;
int part11size,part12size,part13size;
int part21size,part23size,part24size;
int part31size,part32size,part34size;
int part41size,part42size,part43size;


 void   relaxgraph ( int & p ,HGraph & graph ) 
 {

 if( ((struct struct_hgraph  *)(graph.extra))->updated[p]==true ){
//printf("HERE\n");
int unni0=graph.index[p+1]-graph.index[p];;
int unni1=graph.index[p];
for(int unni2=0;unni2<unni0;unni2++){
int ut0=2*(unni1+unni2);
 int ut1=graph.edges[ut0].ipe;
int ut2=graph.edges[ut0+1].ipe;
//printf("%d %d \n",ut1,ut2);

  int   dist2 =((struct struct_hgraph  *)(graph.extra))->dist[ut1];

 HMIN(&(((struct struct_hgraph  *)(graph.extra))->dist[ut1]),((struct struct_hgraph  *)(graph.extra))->dist[p]+ut2,p,changed);//rhs not null


 if( ((struct struct_hgraph  *)(graph.extra))->dist[ut1]<dist2 )((struct struct_hgraph  *)(graph.extra))->updated1[ut1]=true; 

 }//foreach

 }

 }

 void   SSSP ( char    *  name ,char *name1) 
 {

 HGraph  hgraph,hgraph1,hgraph2,hgraph3 ;
 hgraph.readPointsN(name1,4);
 hgraph1.readPointsN(name1,4);
 hgraph2.readPointsN(name1,4);
hgraph3.readPointsN(name1,4);
hgraph.makeNPartitionsMPI(name,0,4); 
 hgraph1.makeNPartitionsMPI(name,1,4); 
 hgraph2.makeNPartitionsMPI(name,2,4); 
 hgraph3.makeNPartitionsMPI(name,3,4);
printf("\noffset hgraph %d %d %d %d\n",hgraph.offset[0],hgraph.offset[1],hgraph.offset[2],hgraph.offset[3]);
printf("\noffset hgraph1 %d %d %d %d\n",hgraph1.offset[0],hgraph1.offset[1],hgraph1.offset[2],hgraph1.offset[3]);
printf("\noffset hgraph2 %d %d %d %d\n",hgraph2.offset[0],hgraph2.offset[1],hgraph2.offset[2],hgraph2.offset[3]);
printf("\noffset hgraph3 %d %d %d %d\n",hgraph3.offset[0],hgraph3.offset[1],hgraph3.offset[2],hgraph3.offset[3]);
part1buff=(struct buffer **)malloc(sizeof(struct buffer*)*4);
part2buff=(struct buffer **)malloc(sizeof(struct buffer*)*4);
part3buff=(struct buffer **)malloc(sizeof(struct buffer*)*4);
part4buff=(struct buffer **)malloc(sizeof(struct buffer*)*4);
for(int i=0;i<4;i++){
part1buff[i]=(struct buffer *)malloc(sizeof(struct buffer)*hgraph.hostparts[0].remote_points);
part2buff[i]=(struct buffer *)malloc(sizeof(struct buffer)*hgraph1.hostparts[0].remote_points);
part3buff[i]=(struct buffer *)malloc(sizeof(struct buffer)*hgraph2.hostparts[0].remote_points);
part4buff[i]=(struct buffer *)malloc(sizeof(struct buffer)*hgraph3.hostparts[0].remote_points);
}
fprintf(stderr, "\n hgraph %d %d \n",hgraph.hostparts[0].npoints,hgraph.hostparts[0].remote_points);
fprintf(stderr, "\n hgraph1 %d %d \n",hgraph1.hostparts[0].npoints,hgraph1.hostparts[0].remote_points);
fprintf(stderr, "\n hgraph2 %d %d \n",hgraph2.hostparts[0].npoints,hgraph2.hostparts[0].remote_points);
fprintf(stderr, "\n hgraph3 %d %d \n",hgraph3.hostparts[0].npoints,hgraph3.hostparts[0].remote_points);
//return; 
int hosthgraph=1;
hgraph.hostparts[0].extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph.hostparts[0],hosthgraph,hgraph.npoints+hgraph.remote_points);
double t1,t2;
t1=rtclock(); 
 #pragma omp parallel  num_threads(12)
 for(int i=0;i<hgraph.npoints+hgraph.remote_points;i++){
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated[i]=false; 
 }//foreach
fprintf(stderr, "hgraph1 %d %d \n",hgraph1.hostparts[0].npoints,hgraph1.hostparts[0].remote_points);
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[0]=0;
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated[0]=true;
//return;
hgraph1.hostparts[0].extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph1.hostparts[0],hosthgraph,hgraph1.npoints+hgraph1.remote_points);
 #pragma omp parallel  num_threads(12)
 for(int i=0;i<hgraph1.npoints+hgraph1.remote_points;i++){
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated[i]=false; 
 }//foreach

hgraph2.hostparts[0].extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph2.hostparts[0],hosthgraph,hgraph2.npoints+hgraph2.remote_points);
 #pragma omp parallel  num_threads(12)
 for(int i=0;i<hgraph2.npoints+hgraph2.remote_points;i++){
 ((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated[i]=false; 
 }//foreach

hgraph3.hostparts[0].extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph3.hostparts[0],hosthgraph,hgraph3.npoints+hgraph3.remote_points);
 #pragma omp parallel  num_threads(12)
 for(int i=0;i<hgraph3.npoints+hgraph3.remote_points;i++){
 ((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated[i]=false; 
}
printf("INIT PARTS DONE %d %d \n",hgraph.hostparts[0].npoints,hgraph1.hostparts[0].npoints);
printf("INIT PARTS DONE %d %d \n",hgraph.hostparts[0].remote_points,hgraph1.hostparts[0].remote_points);
printf("INIT PARTS DONE %d %d \n",hgraph2.hostparts[0].npoints,hgraph3.hostparts[0].npoints);
printf("INIT PARTS DONE %d %d \n",hgraph2.hostparts[0].remote_points,hgraph3.hostparts[0].remote_points);
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[0]=0;
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated[0]=true;
int lchanged=0;
 while(1)  { 
lchanged=0;
 changed=0; 

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph.hostparts[0].npoints;i++)relaxgraph(i,hgraph.hostparts[0]);
printf("changed=%d \n",changed);
lchanged|=changed;
 changed=0; 
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph1.hostparts[0].npoints;i++)relaxgraph(i,hgraph1.hostparts[0]);
printf("changed=%d \n",changed);
lchanged|=changed;
 changed=0; 
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph2.hostparts[0].npoints;i++)relaxgraph(i,hgraph2.hostparts[0]);
printf("changed=%d \n",changed);
lchanged|=changed;
 changed=0; 
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph3.hostparts[0].npoints;i++)relaxgraph(i,hgraph3.hostparts[0]);

printf("changed=%d \n",changed);
lchanged|=changed;
 changed=lchanged; 
 if( changed==0 )break;
//DEVICE 0 SEND
//fprintf(stderr,"hgraph %d %d \n",hgraph.hostparts[0].npoints,hgraph.offset[2]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph.hostparts[0].npoints;i<hgraph.offset[1];i++){//npoints(262145 ) to 376307
int loc;
if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part11size,1);
part1buff[0][loc].vid=hgraph.remotevertexid[i];
part1buff[0][loc].dist=((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[i];
changed=1;
}
((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph %d %d \n",hgraph.offset[2],hgraph.offset[3]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph.offset[1];i<hgraph.offset[2];i++){//376307 to 490503
int loc;
if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part12size,1);
part1buff[1][loc].vid=hgraph.remotevertexid[i];
//printf(" off 1-2 i=%d  ri=%d \n", i,hgraph.remotevertexid[i]);
part1buff[1][loc].dist=((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[i];
changed=changed|2;
}
((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph %d %d \n",hgraph.offset[3],hgraph.offset[4]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph.offset[2];i<hgraph.offset[3];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part13size,1);
part1buff[2][loc].vid=hgraph.remotevertexid[i];
part1buff[2][loc].dist=((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[i];
changed=changed|4;
//printf("off2-3 i=%d  ri=%d \n", i,hgraph.remotevertexid[i]);
}
((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false;
}
//break;
//printf("changed=%d\n",changed);
//DEVICE 1 SEND
//fprintf(stderr,"hgraph1 %d %d \n",hgraph1.hostparts[0].npoints,hgraph1.offset[1]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph1.hostparts[0].npoints;i<hgraph1.offset[1];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part21size,1);
part2buff[0][loc].vid=hgraph1.remotevertexid[i];
part2buff[0][loc].dist=((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph1 %d %d \n",hgraph1.offset[1],hgraph1.offset[3]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph1.offset[1];i<hgraph1.offset[2];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part23size,1);
part2buff[1][loc].vid=hgraph1.remotevertexid[i];
part2buff[1][loc].dist=((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph1 %d %d \n",hgraph1.offset[3],hgraph1.offset[4]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph1.offset[2];i<hgraph1.offset[3];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part24size,1);
part2buff[2][loc].vid=hgraph1.remotevertexid[i];
part2buff[2][loc].dist=((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[i];
//printf("XXXXX");
}
((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false;
}

//DEVICE 2 SEND


//fprintf(stderr,"hgraph2 %d %d \n",hgraph2.hostparts[0].npoints,hgraph2.offset[1]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph2.hostparts[0].npoints;i<hgraph2.offset[1];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part31size,1);
part3buff[0][loc].vid=hgraph2.remotevertexid[i];
part3buff[0][loc].dist=((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph2 %d %d \n",hgraph2.offset[1],hgraph2.offset[2]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph2.offset[1];i<hgraph2.offset[2];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part32size,1);
part3buff[1][loc].vid=hgraph2.remotevertexid[i];
part3buff[1][loc].dist=((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph2 %d %d \n",hgraph2.offset[3],hgraph2.offset[4]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph2.offset[2];i<hgraph2.offset[3];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part34size,1);
part3buff[2][loc].vid=hgraph2.remotevertexid[i];
part3buff[2][loc].dist=((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]=false;
}

// DEVICE 3 send


//fprintf(stderr,"hgraph3 %d %d \n",hgraph3.hostparts[0].npoints,hgraph3.offset[1]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph3.hostparts[0].npoints;i<hgraph3.offset[1];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part41size,1);
part4buff[0][loc].vid=hgraph3.remotevertexid[i];
part4buff[0][loc].dist=((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph3 %d %d \n",hgraph3.offset[1],hgraph3.offset[2]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph3.offset[1];i<hgraph3.offset[2];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part42size,1);
part4buff[1][loc].vid=hgraph3.remotevertexid[i];
part4buff[1][loc].dist=((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]=false;
}
//fprintf(stderr,"hgraph3 %d %d \n",hgraph3.offset[2],hgraph3.offset[3]);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph3.offset[2];i<hgraph3.offset[3];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]){
loc=__sync_fetch_and_add(&part43size,1);
part4buff[2][loc].vid=hgraph3.remotevertexid[i];
part4buff[2][loc].dist=((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[i];
}
((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]=false;
}
fprintf(stderr, "part11=%d part12=%d part13=%d\n",part11size,part12size,part13size);
fprintf(stderr, "part21=%d part23=%d part24=%d\n",part21size,part23size,part24size);
fprintf(stderr, "part13=%d part23=%d part34=%d\n",part31size,part32size,part34size);
fprintf(stderr, "part14=%d part24=%d part34=%d\n",part41size,part42size,part43size);
//DEVICE UPDATE

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part11size;i++){
if(((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part1buff[0][i].vid] > part1buff[0][i].dist){
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part1buff[0][i].vid]=part1buff[0][i].dist;
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->updated1[part1buff[0][i].vid]=true;
}
}

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part12size;i++){
if(((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[part1buff[1][i].vid] > part1buff[1][i].dist){
((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[part1buff[1][i].vid]=part1buff[1][i].dist;
((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->updated1[part1buff[1][i].vid]=true;
}
}

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part13size;i++){
if(((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[part1buff[2][i].vid] > part1buff[2][i].dist){
((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[part1buff[2][i].vid]=part1buff[2][i].dist;
((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->updated1[part1buff[2][i].vid]=true;
}
}

//DEVICE 2 UPDATE

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part21size;i++){
if(((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part2buff[0][i].vid] > part2buff[0][i].dist){
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part2buff[0][i].vid]=part2buff[0][i].dist;
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[part2buff[0][i].vid]=true;
}
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part23size;i++){
if(((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[part2buff[1][i].vid] > part2buff[1][i].dist){
((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[part2buff[1][i].vid]=part2buff[1][i].dist;
((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->updated1[part2buff[1][i].vid]=true;
}
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part24size;i++){
if(((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[part2buff[2][i].vid] > part2buff[2][i].dist){
((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[part2buff[2][i].vid]=part2buff[2][i].dist;
((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->updated1[part2buff[2][i].vid]=true;
}
}

//DEVICE 3 UPDATE

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part31size;i++){
if(((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part3buff[0][i].vid] > part3buff[0][i].dist){
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part3buff[0][i].vid]=part3buff[0][i].dist;
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[part3buff[0][i].vid]=true;
}
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part32size;i++){
if(((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part3buff[1][i].vid] > part3buff[1][i].dist){
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part3buff[1][i].vid]=part3buff[1][i].dist;
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->updated1[part3buff[1][i].vid]=true;
}
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part34size;i++){
if(((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[part3buff[2][i].vid] > part3buff[2][i].dist){
((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->dist[part3buff[2][i].vid]=part3buff[2][i].dist;
((struct struct_hgraph *)(hgraph3.hostparts[0].extra))->updated1[part3buff[2][i].vid]=true;
}
}

//DEVICE 4 UPDATE
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part41size;i++){
if(((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part4buff[0][i].vid] > part4buff[0][i].dist){
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part4buff[0][i].vid]=part4buff[0][i].dist;
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[part4buff[0][i].vid]=true;
}
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part42size;i++){
if(((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part4buff[1][i].vid] > part4buff[1][i].dist){
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part4buff[1][i].vid]=part4buff[1][i].dist;
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->updated1[part4buff[1][i].vid]=true;
}
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part43size;i++){
if(((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[part4buff[2][i].vid] > part4buff[2][i].dist){
((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->dist[part4buff[2][i].vid]=part4buff[2][i].dist;
((struct struct_hgraph *)(hgraph2.hostparts[0].extra))->updated1[part4buff[2][i].vid]=true;
}
}
part11size=part12size=part13size=0;
part21size=part23size=part24size=0;
part31size=part32size=part34size=0;
part41size=part42size=part43size=0;
//printf("changed=%d\n",changed);
 #pragma omp parallel for   num_threads(12)
 for(int i=0;i<hgraph.hostparts[0].npoints;i++){
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated[i]=((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false; 
 }//foreach
 #pragma omp parallel for   num_threads(12)
 for(int i=0;i<hgraph1.hostparts[0].npoints;i++){
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated[i]=((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]; 
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false; 
 }//foreach

 #pragma omp parallel for   num_threads(12)
 for(int i=0;i<hgraph2.hostparts[0].npoints;i++){
 ((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated[i]=((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]; 
 ((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->updated1[i]=false; 
 }//foreach
 #pragma omp parallel for   num_threads(12)
 for(int i=0;i<hgraph3.hostparts[0].npoints;i++){
 ((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated[i]=((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]; 
 ((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->updated1[i]=false; 
 }//foreach

 }
t2=rtclock();
fprintf(stderr, " time=%f \n",(t2-t1)*1000);
int maxdist=0,cnt=0;
 for (int   i =0;i<hgraph.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]>maxdist &&((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]!=1234567890)maxdist=((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i];
printf("%d\n",maxdist);
 for (int   i =0;i<hgraph.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]==1234567890)cnt++;
printf("CNt=%d \n",cnt);
 for (int   i =0;i<hgraph1.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i]>maxdist &&((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i]!=1234567890)maxdist=((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i];

printf("%d\n",maxdist);
 for (int   i =0;i<hgraph1.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i]==1234567890)cnt++;
printf("CNt=%d \n",cnt);

 for (int   i =0;i<hgraph2.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->dist[i]>maxdist &&((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->dist[i]!=1234567890)maxdist=((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->dist[i];
printf("%d\n",maxdist);
 for (int   i =0;i<hgraph2.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph2.hostparts[0].extra))->dist[i]==1234567890)cnt++;
printf("CNt=%d \n",cnt);
 for (int   i =0;i<hgraph1.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->dist[i]>maxdist &&((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->dist[i]!=1234567890)maxdist=((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->dist[i];
printf("%d\n",maxdist);
 for (int   i =0;i<hgraph3.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph3.hostparts[0].extra))->dist[i]==1234567890)cnt++;
printf("CNt=%d \n",cnt);
 return ;

 }

 int   main ( int   argc ,char    *  argv [ ] ) 
 { 


 SSSP(argv[1],argv[2]);//rhs not null


 }
