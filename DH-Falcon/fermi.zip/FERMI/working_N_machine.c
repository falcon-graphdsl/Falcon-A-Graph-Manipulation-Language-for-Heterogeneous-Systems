#include <mpi.h>
#include "HGraph.h"
#include "multicoresssp2.h"
#include <stdio.h>
#include <unistd.h>
int NPARTS;
struct buffer {
int *vid;
int *dist;
}*recvbuff,*sendbuff;
int *recvsize,*sendsize;
int changed;
 void   relaxgraph ( int & p ,HGraph & graph ) 
 {

 if( ((struct struct_hgraph  *)(graph.extra))->updated[p]==true ){
int unni0=graph.index[p+1]-graph.index[p];;
int unni1=graph.index[p];
//printf("unni0 %d unni1 %d \n",unni0,unni1);
for(int unni2=0;unni2<unni0;unni2++){
int ut0=2*(unni1+unni2);
 int ut1=graph.edges[ut0].ipe;
int ut2=graph.edges[ut0+1].ipe;

//printf("ut1 %d ut2 %d \n",ut1,ut2);

  int   dist2 =((struct struct_hgraph  *)(graph.extra))->dist[ut1];

 HMIN(&(((struct struct_hgraph  *)(graph.extra))->dist[ut1]),((struct struct_hgraph  *)(graph.extra))->dist[p]+ut2,p,changed);//rhs not null
 if(((struct struct_hgraph  *)(graph.extra))->dist[ut1]<dist2);//rhs not null
((struct struct_hgraph  *)(graph.extra))->updated1[ut1]=true;//rhs not null
 }//foreach

 }

 }
int main(int argc, char **argv)
{
  int rank;
NPARTS=atoi(argv[3]);
HGraph hgraph;
int changed1;
  char hostname[256];
printf("%s %s %s\n",argv[0],argv[1],argv[2]);
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
int world_size,number=1;
MPI_Comm_size(MPI_COMM_WORLD, &world_size);
 MPI_Status status[4];
MPI_Request request[4];

  gethostname(hostname,255);
hgraph.readPointsN(argv[2],NPARTS);
hgraph.makeNPartitionsMPI(argv[1],rank,NPARTS);
printf("back to main\n");
sendbuff=(struct buffer *)malloc(sizeof(struct buffer )*NPARTS);
recvbuff=(struct buffer *)malloc(sizeof(struct buffer )*NPARTS);
sendsize=(int *)malloc(sizeof(int)*NPARTS);
for(int i=0;i<NPARTS;i++)sendsize[i]=0;
//status=(MPI_Status *)malloc(sizeof(MPI_Status)*NPARTS);
//request=(MPI_Request *)malloc(sizeof(MPI_Request)*NPARTS);
for(int i=0;i<NPARTS;i++){
sendbuff[i].vid=(int *)malloc(sizeof(int)*hgraph.remotepoints);
sendbuff[i].dist=(int *)malloc(sizeof(int)*hgraph.remotepoints);
recvbuff[i].vid=(int  *)malloc(sizeof(int)*(1024*1024));
recvbuff[i].dist=(int  *)malloc(sizeof(int)*(1024*1024));
}
fprintf(stderr, "hgraph %d %d %d\n",hgraph.npoints,hgraph.remotepoints,NPARTS);
int hosthgraph=1;
int number_amount=0;
hgraph.extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph,hosthgraph,hgraph.npoints);
double rt1=rtclock();
 #pragma omp parallel  num_threads(32)
 for(int i=0;i<hgraph.npoints;i++){
 ((struct struct_hgraph  *)(hgraph.extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph.extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph.extra))->updated[i]=false; 
 }//foreach
if(rank==0){
 ((struct struct_hgraph  *)(hgraph.extra))->dist[0]=0; 
 ((struct struct_hgraph  *)(hgraph.extra))->updated[0]=true; 
}
int cnt=0;
int messageno=0;
double comm=0.0,c1,c2;
fprintf(stderr,"ENTERING WHILE rank=%d %d %d %d off[1]=%d\n", rank,hgraph.localpoints,hgraph.remotepoints,hgraph.npoints,hgraph.offset[1]);
 while(1)  { 
 changed=0;
 changed1=0;
++cnt; 
 #pragma omp parallel for   num_threads(32)
for(int i=0;i<hgraph.localpoints;i++)relaxgraph(i,hgraph);
if(rank==0)fprintf(stderr,"\nchaned %d rank %d ",changed,rank);
 #pragma omp parallel for   num_threads(32)
printf("ITR=%d \n",(hgraph.offset[1]-hgraph.localpoints));
for(int i=hgraph.localpoints;i<hgraph.offset[1];i++){
int loc;

if(((struct struct_hgraph  *)(hgraph.extra))->updated1[i]){
loc=__sync_fetch_and_add(&sendsize[0],1);
sendbuff[0].vid[loc]=hgraph.remotevertexid[i];
sendbuff[0].dist[loc]=((struct struct_hgraph *)(hgraph.extra))->dist[i];
}
((struct struct_hgraph *)(hgraph.extra))->updated1[i]=false;
}
for(int kk=2;kk<NPARTS;kk++){
 #pragma omp parallel for   num_threads(32)
for(int i=hgraph.offset[kk-1];i<hgraph.offset[kk];i++){
int loc;
if(((struct struct_hgraph  *)(hgraph.extra))->updated1[i]){
loc=__sync_fetch_and_add(&sendsize[kk-1],1);
//printf("here\n");
sendbuff[kk-1].vid[loc]=hgraph.remotevertexid[i];
sendbuff[kk-1].dist[loc]=((struct struct_hgraph *)(hgraph.extra))->dist[i];
}
((struct struct_hgraph *)(hgraph.extra))->updated1[i]=false;
}
}
//fprintf(stderr,"setup senduff %d parts=%d %d\n",rank,NPARTS,sendsize[0]);
rt1=rtclock();
for(int i=0;i<rank;i++){
MPI_Isend((sendbuff[i].vid), sendsize[i], MPI_INT, i ,messageno, MPI_COMM_WORLD,&request[i]);
}
for(int i=rank+1;i<NPARTS;i++){
MPI_Isend((sendbuff[i-1].vid), sendsize[i-1], MPI_INT, i ,messageno, MPI_COMM_WORLD,&request[i-1]);
}
//fprintf(stderr,"send vid done %d parts=%d\n",rank,NPARTS);
for(int i=0;i<rank;i++){
 MPI_Recv(recvbuff[i].vid,1024*1024, MPI_INT,i, messageno, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
}
for(int i=rank+1;i<NPARTS;i++){
 MPI_Recv(recvbuff[i-1].vid,1024*1024, MPI_INT,i, messageno, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
}
for(int i=0;i<rank;i++){
MPI_Isend((sendbuff[i].dist), sendsize[i], MPI_INT, i ,messageno+1, MPI_COMM_WORLD,&request[i]);
}
for(int i=rank+1;i<NPARTS;i++){
MPI_Isend((sendbuff[i-1].dist), sendsize[i-1], MPI_INT, i ,messageno+1, MPI_COMM_WORLD,&request[i-1]);
}
//fprintf(stderr,"send dist done %d parts=%d\n",rank,NPARTS);
for(int i=0;i<rank;i++){

 MPI_Recv(recvbuff[i].dist,1024*1024, MPI_INT, i,messageno+1, MPI_COMM_WORLD,&status[i]);
}
for(int i=rank+1;i<NPARTS;i++){
 MPI_Recv(recvbuff[i-1].dist,1024*1024, MPI_INT, i,messageno+1, MPI_COMM_WORLD,&status[i-1]);
}
//fprintf(stderr,"send  done %d parts=%d\n",rank,NPARTS);
c2=rtclock();
messageno+=2;
//printf("rank=%d cnt=%d  ",rank,cnt);
for(int kk=0;kk<(NPARTS-1);kk++){
   MPI_Get_count(&status[kk], MPI_INT, &number_amount);
printf("rank=%d %d ",rank,number_amount);
 #pragma omp parallel for   num_threads(32)
for(int i=0;i<number_amount;i++){

int vertex= recvbuff[kk].vid[i];
int dist= recvbuff[kk].dist[i];
if(((struct struct_hgraph *)(hgraph.extra))->dist[vertex] >dist){
((struct struct_hgraph *)(hgraph.extra))->dist[vertex]=dist;
((struct struct_hgraph *)(hgraph.extra))->updated1[vertex]=true;
changed=1;
} 
}
}
comm=comm+(c2-c1)*1000;
 #pragma omp parallel for   num_threads(32)
for(int i=0;i<hgraph.localpoints;i++){
((struct struct_hgraph *)(hgraph.extra))->updated[i]=((struct struct_hgraph *)(hgraph.extra))->updated1[i];
((struct struct_hgraph *)(hgraph.extra))->updated1[i]=false;
}
if(rank==0)fprintf(stderr,"CHANED %d rank %d ",changed,rank);
//printf("\nrank=%d cnt=%d sizes %d %d %d \n",rank,cnt,sendsize[0],sendsize[1],sendsize[2]);
for(int i=0;i<NPARTS;i++)sendsize[i]=0;
for(int i=0;i<NPARTS;i++){
if(i!=rank)MPI_Isend(&changed, 1, MPI_INT, i,messageno, MPI_COMM_WORLD,&request[i]);
}

for(int i=0;i<NPARTS;i++){
if(i!=rank)MPI_Recv(&changed1,1, MPI_INT, i,messageno, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
changed=changed+changed1;
}
messageno+=NPARTS;
if(rank==0)fprintf(stderr,"CHANED %d rank %d ",changed,rank);
if(changed==0)break;
}
double rt2=rtclock();
printf(" %d \n",cnt);
printf("TIME =%f comm=%f\n",(rt2-rt1)*1000,comm);
  printf("Hello world!  I am process number: %d on host %s\n", rank, hostname);
  MPI_Finalize();
int maxdist=0,cnt1=0;
 for (int   i =0;i<hgraph.localpoints;i++)if(((struct struct_hgraph  *)(hgraph.extra))->dist[i]>maxdist /*&&((struct struct_hgraph  *)(hgraph.extra))->dist[i]!=1234567890*/)maxdist=((struct struct_hgraph  *)(hgraph.extra))->dist[i];
printf(" %d %d\n",rank,maxdist);
// for (int   i =0;i<hgraph.npoints;i++)if(((struct struct_hgraph  *)(hgraph.extra))->dist[i]==1234567890)cnt1++;
//printf("%d\n",cnt1);
  return 0;
}

