#ifndef SYMTAB_H
#define SYMTAB_H       1
#include "symtabold.h"
#endif
