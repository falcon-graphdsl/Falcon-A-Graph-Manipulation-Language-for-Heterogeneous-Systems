#include<stdio.h>
#include<iostream>
#include<atomic>
 int HADD(float  *t1,float t2, int ch){
__sync_fetch_and_add((unsigned long *)t1,(unsigned long )t2);
}
main(){
float d=2.5;
float dd=7.3;
float t1= HADD(&dd,d,0);
fprintf(stderr,"float %f\n",t1);
}
