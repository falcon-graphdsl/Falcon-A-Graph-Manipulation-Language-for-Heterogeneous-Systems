 #include "HGraph1.h"
 #include<sys/time.h>
#include<unistd.h>
struct struct_hgraph { 
int   *dist ;//has to given size of property type
bool  *updated1 ;//has to given size of property type
bool  *updated ;//has to given size of property type
bool *light;
};
void alloc_extra_hgraph(HGraph &hgraph,int flag,int npoints) {
 if(flag==0)hgraph.extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph )) ;
((struct struct_hgraph  *)hgraph.extra)->updated1=(bool *)malloc(sizeof(bool) * npoints) ;
((struct struct_hgraph  *)hgraph.extra)->updated=(bool *)malloc(sizeof(bool) *npoints) ;
((struct struct_hgraph  *)hgraph.extra)->dist=(int  *)malloc(sizeof(int ) * npoints) ;
((struct struct_hgraph  *)hgraph.extra)->light=(bool  *)malloc(sizeof(bool ) * hgraph.nedges) ;
}
void alloc_extra_graph(GGraph &graph,int flag,int npoints) {
 if(flag==0)
cudaMalloc(&(graph.extra),sizeof(struct struct_hgraph )) ;
struct struct_hgraph temp;
cudaMemcpy(&temp,graph.extra,sizeof(struct struct_hgraph),cudaMemcpyDeviceToHost);
cudaMalloc(&(temp.updated1),sizeof(bool) * npoints) ;
cudaMalloc(&(temp.updated),sizeof(bool) * npoints) ;
cudaMalloc(&(temp.dist),sizeof(int) * npoints) ;
cudaMemcpy(graph.extra,&temp,sizeof(struct struct_hgraph),cudaMemcpyHostToDevice);
}
