#include "multicoresssp2.h"
 int   changed =0, hchanged ;
struct buffer{
int vid;
int dist;
}*part1buff,*part2buff;
int part1size,part2size;
 void   relaxgraph ( int & p ,HGraph & graph ) 
 {

 if( ((struct struct_hgraph  *)(graph.extra))->updated[p]==true ){

int unni0=graph.index[p+1]-graph.index[p];;
int unni1=graph.index[p];
for(int unni2=0;unni2<unni0;unni2++){
int ut0=2*(unni1+unni2);
 int ut1=graph.edges[ut0].ipe;
int ut2=graph.edges[ut0+1].ipe;


  int   dist2 =((struct struct_hgraph  *)(graph.extra))->dist[ut1];

 HMIN(&(((struct struct_hgraph  *)(graph.extra))->dist[ut1]),((struct struct_hgraph  *)(graph.extra))->dist[p]+ut2,p,changed);//rhs not null


 if( ((struct struct_hgraph  *)(graph.extra))->dist[ut1]<dist2 )((struct struct_hgraph  *)(graph.extra))->updated1[ut1]=true; 

 }//foreach

 }

 }

 void   SSSP ( char    *  name ,char *name1) 
 {

 HGraph  hgraph,hgraph1;

 

 

 //npoints manually set to 32M in readPoints function.
 //part_ids stores partition id of each point
 //local_ids stores local id of each point in its partition.
 //localid1 and localid2 stores points in partition 0/1 and parition 1/2 respectively
 hgraph.readPointsN(name1,2);
 hgraph1.readPointsN(name1,2);
//return;
//hostparts allocated with num_parts(2 here).
//edges and points in each hostpart is allocated with total edges in graph. this needs to be modified.
//remote_ids stores whether destination point of edge is part of remote partition(true) or not(false). But local for each iteration.
//remotebuff[point] stores location for remote point in edges array.
//locations are from total_local_points to (total_local_points+number_of_remote_points)
//ttindex stores total edges in the current partition.
// hgraph.makePartitions(name,2); 
 hgraph.makeNPartitionsMPI(name,0,2); 
 hgraph1.makeNPartitionsMPI(name,1,2); 
//return; 
part1buff=(struct buffer *)malloc(sizeof(struct buffer)*hgraph.hostparts[0].remote_points);
part2buff=(struct buffer *)malloc(sizeof(struct buffer)*hgraph1.hostparts[0].remote_points);
//return;
fprintf(stderr, "hgraph %d %d \n",hgraph.hostparts[0].npoints,hgraph.hostparts[0].remote_points);
int hosthgraph=1;
hgraph.hostparts[0].extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph.hostparts[0],hosthgraph,hgraph.npoints+hgraph.remote_points);
double t1,t2;
t1=rtclock(); 
 #pragma omp parallel  num_threads(12)
 for(int i=0;i<hgraph.npoints+hgraph.remote_points;i++){
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated[i]=false; 
 }//foreach
fprintf(stderr, "hgraph1 %d %d \n",hgraph1.hostparts[0].npoints,hgraph1.hostparts[0].remote_points);
hgraph1.hostparts[0].extra=(struct struct_hgraph  *)malloc(sizeof(struct struct_hgraph ));
 alloc_extra_hgraph(hgraph1.hostparts[0],hosthgraph,hgraph1.npoints+hgraph1.remote_points);
 #pragma omp parallel  num_threads(12)
 for(int i=0;i<hgraph1.npoints+hgraph1.remote_points;i++){
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i]=1234567890; 
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false; 
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated[i]=false; 
 }//foreach

 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[0]=0; 

 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated[0]=true; 
printf("INIT PARTS DONE %d %d \n",hgraph.hostparts[0].npoints,hgraph1.hostparts[0].npoints);
printf("INIT PARTS DONE %d %d \n",hgraph.hostparts[0].remote_points,hgraph1.hostparts[0].remote_points);
//return;
 while(1)  { 

 changed=0; 

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph.hostparts[0].npoints;i++)relaxgraph(i,hgraph.hostparts[0]);
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<hgraph1.hostparts[0].npoints;i++)relaxgraph(i,hgraph1.hostparts[0]);

 if( changed==0 )break;
//update the two paritions , create buffer, send , updat

 #pragma omp parallel for   num_threads(12)
for(int i=hgraph.hostparts[0].npoints;i<hgraph.hostparts[0].npoints+hgraph.hostparts[0].remote_points;i++){
int loc;
if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]){
//if(((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[hgraph.remotevertexid[i]] > ((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[i]){
//add to buffer
loc=__sync_fetch_and_add(&part1size,1);
part1buff[loc].vid=hgraph.remotevertexid[i];
part1buff[loc].dist=((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[i];

//}
}
}
printf("changed=%d\n",changed);
 #pragma omp parallel for   num_threads(12)
for(int i=hgraph1.hostparts[0].npoints;i<hgraph1.hostparts[0].npoints+hgraph1.hostparts[0].remote_points;i++){
int loc;
if(((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]){
//if(((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[hgraph1.remotevertexid[i]] > ((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[i]){
//add to buffer

loc=__sync_fetch_and_add(&part2size,1);
part2buff[loc].vid=hgraph1.remotevertexid[i];
part2buff[loc].dist=((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[i];
changed=4;

//}
}
((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false;
}
//send and  receive . not needed here
//update
//

 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part1size;i++){
if(((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part1buff[i].vid] > part1buff[i].dist){
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->dist[part1buff[i].vid]=part1buff[i].dist;
((struct struct_hgraph *)(hgraph1.hostparts[0].extra))->updated1[part1buff[i].vid]=true;
}
}
 #pragma omp parallel for   num_threads(12)
for(int i=0;i<part2size;i++){
if(((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part2buff[i].vid] > part2buff[i].dist){
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->dist[part2buff[i].vid]=part2buff[i].dist;
((struct struct_hgraph *)(hgraph.hostparts[0].extra))->updated1[part2buff[i].vid]=true;
}
}
part1size=part2size=0;
printf("changed=%d\n",changed);
 #pragma omp parallel for   num_threads(12)
 for(int i=0;i<hgraph.hostparts[0].npoints;i++){
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated[i]=((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]; 
 ((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->updated1[i]=false; 
 }//foreach
 #pragma omp parallel for   num_threads(12)
 for(int i=0;i<hgraph1.hostparts[0].npoints;i++){
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated[i]=((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]; 
 ((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->updated1[i]=false; 
 }//foreach


 }
t2=rtclock();
fprintf(stderr, " time=%f \n",(t2-t1)*1000);
int maxdist=0;
 for (int   i =0;i<hgraph.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]>maxdist /*&&((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]!=1234567890*/)maxdist=((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i];
printf("%d\n",maxdist);
 for (int   i =0;i<hgraph1.hostparts[0].npoints;i++)if(((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i]>maxdist /*&&((struct struct_hgraph  *)(hgraph.hostparts[0].extra))->dist[i]!=1234567890*/)maxdist=((struct struct_hgraph  *)(hgraph1.hostparts[0].extra))->dist[i];

printf("%d\n",maxdist);

 return ;

 }

 int   main ( int   argc ,char    *  argv [ ] ) 
 { 


 SSSP(argv[1],argv[2]);//rhs not null


 }
